# LoginPage_PHP-MySql
Complete Login Form With Session Variable Using Only PHP & MySQL. 
If I have time, I will use the CSS to set all the graphics in the end. 

First, I'll make sure the login is working properly, 
then I'll beautify everything else. 

ND. 
Soon, I will insert this code in another repository, 
I will create a specific CRM (Content Relationship Manager) for commercial agents and companies 
that deal with sales and signing of contracts, 
very useful and required in Italy.
